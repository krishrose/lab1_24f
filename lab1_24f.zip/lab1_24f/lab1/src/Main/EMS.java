package Main;

import lab1_24f.builder.EmployeeDirector;
import lab1_24f.builder.FullTimeEmployeeBuilder;
import lab1_24f.employee.Employee;
import lab1_24f.factory.EmployeeFactory;
import singleton.EmployeeManager;

public class EMS {
    public static void main(String[] args) {
    	EmployeeManager manager = EmployeeManager.getInstance();

    	FullTimeEmployeeBuilder ftBuilder = new FullTimeEmployeeBuilder();
        EmployeeDirector director = new EmployeeDirector(ftBuilder);
        Employee ftEmployee = director.constructEmployee("Alice", "Engineering", "Engineer", 38, 85000);
       manager.registerEmployee(ftEmployee);

        EmployeeFactory creator = new EmployeeFactory();
        Employee ptEmployee = creator.buildEmployee("PartTime");
        ptEmployee.setEmpName("Bob");
        ptEmployee.setDept("Marketing");
        ptEmployee.setRole("Coordinator");
        ptEmployee.setWorkingHoursPerWeek(18);
        ptEmployee.setSalary(30000);

        manager.registerEmployee(ptEmployee);

        manager.listEmployees();
    }
}

