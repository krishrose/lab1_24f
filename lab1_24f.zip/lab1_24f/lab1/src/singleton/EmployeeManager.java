package singleton;

import java.util.ArrayList;
import java.util.List;

import lab1_24f.employee.Employee;

public class EmployeeManager {
    private static EmployeeManager instance;
    private List<Employee> employeeList;

    private EmployeeManager() {
        employeeList = new ArrayList<>();
    }

    public static EmployeeManager getInstance() {
        if (instance == null) {
            instance = new EmployeeManager();
        }
        return instance;
    }

    public void registerEmployee(Employee employee) {
        employeeList.add(employee);
    }
    
    public void RemoveEmployee(Employee employee) {
    	employeeList.remove(employee);  
    	}

    public void listEmployees() {
        for (Employee employee : employeeList) {
            System.out.println("Name: " + employee.getEmpName());
            System.out.println("Department: " + employee.getDept());
            System.out.println("Role: " + employee.getRole());
            System.out.println("Hours: " + employee.getHours());
            System.out.println("Salary: " + employee.getEmpSalary());
            System.out.println();
        }
    }
}
