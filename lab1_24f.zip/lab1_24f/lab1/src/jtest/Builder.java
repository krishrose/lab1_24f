package jtest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import lab1_24f.builder.EmployeeDirector;
import lab1_24f.builder.FullTimeEmployeeBuilder;
import lab1_24f.employee.Employee;
class Builder {

	  @Test
	    public void testBuildFullTimeEmployee() {
	        FullTimeEmployeeBuilder builder = new FullTimeEmployeeBuilder();
	        EmployeeDirector director = new EmployeeDirector(builder);
	        Employee employee = director.constructEmployee("John", "Engineering", "Engineer", 40, 90000);
	        // Check if the employee was built with the correct details
	        assertEquals("John", employee.getEmpName());
	        assertEquals("Engineering", employee.getDept());
	        assertEquals("Engineer", employee.getRole());
	        assertEquals(40, employee.getHours());
	        assertEquals(90000, employee.getEmpSalary());
	    }

}
