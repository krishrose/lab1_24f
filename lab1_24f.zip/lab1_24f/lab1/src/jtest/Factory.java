package jtest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import lab1_24f.employee.Employee;
import lab1_24f.employee.FullTimeEmployee;
import lab1_24f.employee.PartTimeEmployee;
import lab1_24f.factory.EmployeeFactory;
class Factory {

    // Factory Pattern Tests
    @Test
    public void testCreateFullTimeEmployee() {
        EmployeeFactory factory = new EmployeeFactory();
        Employee employee = factory.buildEmployee("FullTime");
        // Ensure the factory created a FullTimeEmployee
        assertTrue(employee instanceof FullTimeEmployee);
    }

    @Test
    public void testCreatePartTimeEmployee() {
        EmployeeFactory factory = new EmployeeFactory();
        Employee employee = factory.buildEmployee("PartTime");
        // Ensure the factory created a PartTimeEmployee
        assertTrue(employee instanceof PartTimeEmployee);
    }


}
