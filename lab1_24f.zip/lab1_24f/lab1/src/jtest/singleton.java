package jtest;
import org.junit.jupiter.api.Test;
import singleton.EmployeeManager;

import static org.junit.jupiter.api.Assertions.*;

public class singleton {

    // Singleton Pattern Tests
    @Test
    public void testSingletonInstance() {
        EmployeeManager instance1 = EmployeeManager.getInstance();
        EmployeeManager instance2 = EmployeeManager.getInstance();
        // Ensure both instances are the same (Singleton)
        assertSame(instance1, instance2);
    }

    
}
