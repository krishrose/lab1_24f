package lab1_24f.factory;

import lab1_24f.employee.Employee;
import lab1_24f.employee.FullTimeEmployee;
import lab1_24f.employee.PartTimeEmployee;

public class EmployeeFactory {
    public Employee buildEmployee(String type) {
        switch (type) {
            case "FullTime":
                return new FullTimeEmployee();
            case "PartTime":
                return new PartTimeEmployee();
            default:
                return null;
        }
    }
}
