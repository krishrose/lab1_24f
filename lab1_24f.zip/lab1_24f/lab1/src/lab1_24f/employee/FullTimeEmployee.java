package lab1_24f.employee;

public class FullTimeEmployee extends Employee {

    @Override
    public void clockIn() {
        System.out.println(empName + " clocked in (Full-Time)");
    }

    @Override
    public void clockOut() {
        System.out.println(empName + " clocked out (Full-Time)");
    }

    @Override
    public void monitorWorkHours() {
        System.out.println(empName + " worked " + hours + " hours this week.");
    }
}
