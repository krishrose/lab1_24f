package lab1_24f.employee;

public abstract class Employee {
    protected String empId;
    protected String empName;
    protected String dept;
    protected String role;
    protected int hours;
    protected double empSalary;

    public String getEmpId() { return empId; }
    public void setEmpId(String empId) { this.empId = empId; }
    public String getEmpName() { return empName; }
    public void setEmpName(String empName) { this.empName = empName; }
    public String getDept() { return dept; }
    public void setDept(String dept) { this.dept = dept; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public int getHours() { return hours; }
    public void setWorkingHoursPerWeek(int hours) { this.hours = hours; }
    public double getEmpSalary() { return empSalary; }
    public void setSalary(double empSalary) { this.empSalary = empSalary; }

    public abstract void clockIn();
    public abstract void clockOut();
    public abstract void monitorWorkHours();
}
