package lab1_24f.employee;

public class PartTimeEmployee extends Employee {

    @Override
    public void clockIn() {
        System.out.println(empName + " clocked in (Part-Time)");
    }

    @Override
    public void clockOut() {
        System.out.println(empName + " clocked out (Part-Time)");
    }

    @Override
    public void monitorWorkHours() {
        System.out.println(empName + " worked " + hours + " hours this week.");
    }
}
