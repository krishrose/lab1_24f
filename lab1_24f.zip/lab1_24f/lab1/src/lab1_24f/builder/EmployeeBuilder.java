package lab1_24f.builder;

import lab1_24f.employee.Employee;

public interface EmployeeBuilder {
    EmployeeBuilder setName(String name);
    EmployeeBuilder setDept(String dept);
    EmployeeBuilder setRole(String role);
    EmployeeBuilder setWorkingHours(int hours);
    EmployeeBuilder setSalary(double salary);
    Employee build();
}
