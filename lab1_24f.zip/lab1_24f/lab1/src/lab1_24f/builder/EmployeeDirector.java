package lab1_24f.builder;

import lab1_24f.employee.Employee;

public class EmployeeDirector {
    private EmployeeBuilder builder;

    public EmployeeDirector(EmployeeBuilder builder) {
        this.builder = builder;
    }

    public Employee constructEmployee(String name, String dept, String role, int hours, double salary) {
        return builder.setName(name)
                      .setDept(dept)
                      .setRole(role)
                      .setWorkingHours(hours)
                      .setSalary(salary)
                      .build();
    }
}
