package lab1_24f.builder;

import lab1_24f.employee.Employee;
import lab1_24f.employee.FullTimeEmployee;

public class FullTimeEmployeeBuilder implements EmployeeBuilder {
    private FullTimeEmployee employee;

    public FullTimeEmployeeBuilder() {
        employee = new FullTimeEmployee();
    }

    @Override
    public EmployeeBuilder setName(String name) {
        employee.setEmpName(name);
        return this;
    }

    @Override
    public EmployeeBuilder setDept(String dept) {
        employee.setDept(dept);
        return this;
    }

    @Override
    public EmployeeBuilder setRole(String role) {
        employee.setRole(role);
        return this;
    }

    @Override
    public EmployeeBuilder setWorkingHours(int hours) {
        employee.setWorkingHoursPerWeek(hours);
        return this;
    }

    @Override
    public EmployeeBuilder setSalary(double salary) {
        employee.setSalary(salary);
        return this;
    }

    @Override
    public Employee build() {
        return employee;
    }
}
